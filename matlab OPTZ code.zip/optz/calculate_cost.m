function c_total = calculate_cost(x, filename)
    % ... (rest of your code)
    opts = detectImportOptions(filename, 'VariableNamingRule', 'preserve');
    dataTable = readtable(filename, opts);
    % Extract L_ice and N from the input vector
    L_ice = x(1);
    N = x(2);
    m_dot_HTF = x(3); % Mass flow rate of HTF
    T_HTF_in = x(4); % Inlet temperature of HTF
    T_HTF_out = x(5); % Outlet temperature of HTF
    D_o = x(6); % Outer diameter of the tube
    tube_t = x(7); % Tube thickness
  T_storing = x(8); % Eighth decision variable
    T_c_b = x(9);     % Ninth decision variable

% The discharing cycle: 
% The following may be used to design AHS in future
P_sat_1 = 4.951e3; % [Pa] this is the staurated pressure at T_1
P_sat_2 = 2.811e3; % [Pa] this is the saturated pressure at T_2
relative_humidity_1 = 0.7; 
relative_humidity_2 = 0.55;
P_amb = 100e3; % Pa
T_1 = 32.7; % [Celsius]  % this is the max ambient temp in the hottest day in Melbourne Fl
T_2 = 23; % Celsius
cp_air_AHU = 1005; % J/kg*C
h_g1 = 2560e3; % J/kg
h_g2 = 2543e3; % J/kg
% the cooling load of the office building in whuch the integrated pcm-TES
% is used for
Q_c_dot = 2e3; % Watts %the peak cooling load required,  in futuure I can design my system over the daily profile of the cooling load
% Operating hours:
time_dc = 11  %[h] Cooling load for 11 hours, working hours from 7 AM to 6 PM, assuming the system is idle in the rest of the day 
Q_c = Q_c_dot *time_dc  % taragted cooling capacity in kWh
eta_st = 0.9 % the storage efficiency 
% the required storage capacity :
Q_st = Q_c / eta_st     %in kWh  
Q_st_dot = Q_st/time_dc  % in kW
% Calculations for AHS that may be used for future calculations 
omega_1 = (0.066 * P_sat_1 * relative_humidity_1) / (P_amb - (P_sat_1 * relative_humidity_1));
omega_2 = (0.066 * P_sat_2 * relative_humidity_2) / (P_amb - (P_sat_2 * relative_humidity_2));
delta_h_AHU = cp_air_AHU * (T_1 - T_2) + ((h_g1 * omega_1) - (h_g2 * omega_2));
m_dot_air = Q_c_dot / delta_h_AHU; % this is the required mass flow rate of the air inside teh AHU 

% Discharging Cycle- Heat transfer fluid used to facilitate teh heat
% transfer between the pcm inside the tank and the discharing process isa
% mixture of glycol-water mixture with 20 % concentration 

T_fp_HTF = -0.07306; % Celsius
cp_HTF = 4191; % J/kg*C
T_HTF_out = (3 + 5) / 2;  % [C]this is initiated value and it will be optimzed later 
T_HTF_in = (11 + 13) / 2;  %[C] this is initiated value and it will be optimized later 
T_HTF_avg = (T_HTF_out + T_HTF_in) / 2; % [C]assume constant fluid proprties at this Temp value regardless of teh adjusmenrts that the optz will make
k_HTF = 0.5759; % W/m-C
Pr_HTF = 10.17;
mu_HTF = 0.001398; % Pa-s
rho_HTF = 1000 %kg/m^3

% PCM  Properties(ice)
T_melting_ice = 0; % Celsius
h_l_ice = 336e3; % J/kg    % latent heat 
rho_ice = 917; % kg/m^3    
k_ice = 2.22; % W/m-C
m_dot_HTF = 0.1; % [kg/s ] , this is the initiated value of the mass flow rate of HTF, it will be optimzed 
Q_st_J = 87984e3; % J      % stoarge capacity required in J 
V_ice = Q_st_J / (rho_ice * h_l_ice);
A_st = 6 * pi * (V_ice / (2 * pi) )^(2/3);  % teh shape of the storage is cylnder with height equals to teh Diamter for better heat transfer raesons as concluded from the litrature review 
R_insulated = 1980e-3; % m^2*C/W  ., this typical value for thermal insulation of the thermal  stoarge tank 
t_dc = 11; % [h] discharing time 
t_ch = 13; % [h] charging time 

Q_leakage_dc=  t_dc * ((T_1 - T_HTF_out) * A_st)/R_insulated ; % estimated leakage of the tank dueing discharing process 
Q_leakage_ch=t_ch *((T_1 - T_melting_ice) * A_st)/ R_insulated;% estimated leakage of the tank dueing charing process 

% the pcm thermal stoarge can be treated as a heat exchanger and design for
% using the LMTD method to design for the length of the tubes carrying HTF
% inside the tank,

D_o = 6.4e-3; %[ m ] , outer tube diamter, initiated value,     it's going to be optimzed 
tube_t = 9.2e-4; % [m] , thickness of the tube , initiated value, it's going to be optimized 
D_i = D_o - tube_t;   % [m] inner tube diamter 
p_pitch = max((1.25e-3) * D_o, (D_o + 6.4e-3)); % m this repersnts r_max , which is tehg maximum distance taht teh PCM will soldifies 
k_wall = 15 ; % [W/m-C] stainless steel is choosen for the material of tube, it's not typiacl but it's the only materail that I founf cost correlatuoions for it 
L_ice = 3   % this an initiated value of tube length carrying the HTF required inside the pcm-stoarge tank , will be optimized based on cost and Pressure drop
N=60        % number of tube requid, will be optimzzed based on cost and pressure drop  
 
% Calculate resistances for PCM-HEX 
A_cross_tube = 0.25 * pi * (D_i^2) * N;
Re_f = m_dot_HTF * D_i / (A_cross_tube * mu_HTF); % where Re_f is teh Rynold of HTF , depnds on mass flow rate 
L_plus = L_ice/ (D_i*Re_f);
f_fd = 1/( (0.72*log(Re_f))-1.64           )^2;
if Re_f <= 2300
    Nusselt_f_ice = 3.66 + (0.0668 * (D_i / L_ice) * Pr_HTF * Re_f) / (1 + 0.04 * ((D_i / L_ice) * Re_f * Pr_HTF)^(2/3));
else
    Nusselt_f_ice = 0.023 * Re_f^0.8 * Pr_HTF^0.4;
end
if Re_f <= 2300
f_avg = (4/Re_f)* (   (3.44/sqrt(L_plus))       +  ( (  (1.25/(4*L_plus))+(64/4)- (3.44/sqrt(L_plus) )   )/( 1+(0.00021/L_plus^2) )      )      );
else
   f_avg= f_fd*(1+(D_i/L_ice)^0.7);
end
 h_f_ice  = Nusselt_f_ice *k_HTF / D_i ; % this is the heat trasnfer coeff in the HTF side 

% Initialize variables

R_HTF = 1 / (D_i * pi * h_f_ice * L_ice);% [C/W] thermal resistance due to convection of HTF inside the tubes 
R_wall = log(D_o / D_i) / (2 * pi * k_wall * L_ice);  % [C/W] conductive thermal resistance 
pc_f_values = 0.005:0.01:0.995; % Range of pc_f values, which is typically an alternative for time that takes pcm to completely soldifes and reach r_max, this will alter the value of thermal resistance of teh PCM 
sum_R_ice = 0; % initiated 
% Loop through pc_f values
for pc_f = pc_f_values

R_ice = (log((pc_f * ((p_pitch * 0.5)^(2) - (D_o * 0.5)^(2)) + (D_o * 0.5)^(2))^0.5 / (D_o * 0.5))) / (2 * pi * k_ice * L_ice);
sum_R_ice = R_ice - sum_R_ice
end 
R_t_ice =  R_HTF + R_wall+ sum_R_ice; % total thermal resistance 
Delta_T_1 = T_HTF_in - T_melting_ice ;
Delta_T_2 = T_HTF_out - T_melting_ice;
LMTD = (Delta_T_1- Delta_T_2)/ log(Delta_T_1/Delta_T_2 );
U = 1 / (R_t_ice * D_o * pi * L_ice);
Q_st_dot = (U*pi*D_o* L_ice *LMTD *N);
A_ice = N *pi*D_o *L_ice ;
L_ice =A_ice/N *pi*D_o   % required length of HTF tubes 
%% I'll save the following for future calculations when the dimensiions of tank are specified:
V_tank = V_ice/(1-0.20)% allow an additional 20% for the pipes and clearance
height = ( V_tank /( pi*0.25) )^(1/3) % height of the tank which is equal to its diamter 
V_tube = N*pi*0.25*(D_o^2)*L_ice
V_ice_ava= V_tank-V_tube
 
%cost calculations of the tubing system inside the tank:
F_m =  2.70 + (10.7639*A_ice)^(0.07) % material cost factor, for stainless steal
F_p = F_m % low gauge pressure , pressure gage pressure factor


%FL is a cost factor depends on  tube length, gioven for differnt tube
%lengths 
tubeLengths = [0.1;0.4;1.6;2.4384; 3.6576; 4.8768; 6.0960];
FLValues = [1.6;1.45;1.3;1.25; 1.12; 1.05; 1.00];

% New tube lengths for interpolation
newTubeLengths = [L_ice];

% Initialize array to store interpolated FL values
interpolatedFL = zeros(size(newTubeLengths));

%  interpolation:
for i = 1:length(newTubeLengths)
    % Find the two closest data points for interpolation
    [~, idx] = min(abs(tubeLengths - newTubeLengths(i)));
    
    % Linear interpolation formula % Matlab handbook
    interpolatedFL(i) = FLValues(idx) + ...
                        (newTubeLengths(i) - tubeLengths(idx)) / ...
                        (tubeLengths(idx + 1) - tubeLengths(idx)) * ...
                        (FLValues(idx + 1) - FLValues(idx));
end 
% now calcualting the pressure drop for pumping cost:
P_drop = f_avg*(L_ice/D_i)*(m_dot_HTF^(2))/(2*rho_HTF*A_cross_tube^(2));
V_rate = m_dot_HTF/rho_HTF;
eta_pump = 0.8 % efficiancy of the pump, ignore other etas 
W_pumping_inlet  = P_drop*V_rate/eta_pump
C_pumping = 705.48* (W_pumping_inlet^(0.71))* (1+ (0.2/(1-eta_pump)));%pimping cost 
C_st = 8.67 *10^(2.911*exp(0.1416*log(V_ice)));   % storage unit cost 

%Design of the components of the charing cycle: 
%stadrized given dimensions of teh plate HEX:
W_e = 0.253 ; %[m] width of the plate
L_p = 0.456 ;%[m]
t_p = 0.002 ;%[m] // Plate thickness
beta_chovron = 0.785 ; % // Chevron angle
b = 0.002     ;   %[m]
pco = 0.004   ;   %[m] // corrugation pitch
X_x= (b*pi)/ pco ; % // Wavenumber
phi = (1/6) * ( 1+ (1+(X_x^2) )^(0.5)+ 4*(1+( (X_x^2)/2) )^(0.5) );  %// Arae Increase Factor
D_h = (2*b)/ phi ; %[m]
d_eq = 2*b  ;     %// eqivalint diameter
k_wall = 15;% [W/m-K]  %//conductivity of stainless steel % note that I forgot that I used copper in the EES code 






% Given Temps 
T_c_b = -20 ;    % this will be optimized  T_c_b is the saturated evaporator temp and it varies from -30 to T_storing_Temp 
T_wb= 26.6         % this is the wet bulp temp opteined from the design cheet of A/C system in Melboure Fl
T_c_in_cond = 35 %The temp of the cooling water coming from the cooling tower to the condenser 
T_c_out_cond = 40.56   % the temp the cooling water coming from out teh condenser 
T_coooling_tower_df =T_c_out_cond-T_c_in_cond % a temp differnce of 5.56 is typical for cooling tower 
T_h_cond = T_c_out_cond+5; % The saturated temp of condenser,T_h_cond must be kept above T_wetbulp and making sure does not exceed 60 C 
Temp1= T_h_cond;   % Temp1, calling the proprties of R134a at Temp_1, this value is fixed and not going to be optz for now
Temp2 = T_c_b;      % Temp2, calling the proprties of R134 at Temp_2,  this valu will be varied, optimized 

% proprties of R-134a at saturated Temp for evaporator  

propertiesAtTemp2 = getPropertiesForTemp(Temp2 , dataTable);
cp_h_evp = propertiesAtTemp2.cpLiquid;
k_h_evp = propertiesAtTemp2.kLiquid;
pr_h_evp = propertiesAtTemp2.PrLiquid;
mu_h_evp = propertiesAtTemp2.muLiquid;
rho_h_evp_L = propertiesAtTemp2.DensityLiquid;
rho_h_evp_V = propertiesAtTemp2.DensityVapor;
h_f_evp = propertiesAtTemp2.hf;
h_g_evp = propertiesAtTemp2.hg;
P_evap = propertiesAtTemp2.Pressure

% proprties of R-134a at saturated Temp for condenser 
propertiesAtTemp1 = getPropertiesForTemp(Temp1 , dataTable);
cp_h_c = propertiesAtTemp1.cpLiquid;
k_h_c = propertiesAtTemp1.kLiquid;
pr_h_c = propertiesAtTemp1.PrLiquid;
mu_h_c = propertiesAtTemp1.muLiquid;
rho_h_c_L = propertiesAtTemp1.DensityLiquid;
rho_h_c_V = propertiesAtTemp1.DensityVapor;
h_f_c = propertiesAtTemp1.hf;
h_g_c= propertiesAtTemp1.hg;
P_cond = propertiesAtTemp1.Pressure

% storing the proprties in the following variables for evaporator:
cp_c_b =cp_h_evp ; 
k_c_b = k_h_evp ;
pr_c_b = pr_h_evp;
mu_c_b = mu_h_evp;
rho_c_b_L =   rho_h_evp_L ;     %density(R-134a,P=P_c_b, x=0)
rho_c_b_V = rho_h_evp_V  ;      %density(R-134a,P=P_c_b, x=1) 
h_in_evap = h_f_evp     ;
h__out_evap = h_g_evp;

% Design the evaporator:

Q_evap_dot = Q_st_dot / t_ch ; %W
m_dot_c_b = Q_evap_dot  /(h__out_evap - h_in_evap )   ; % [kg/s], the mass flow rate in teh charing cycle 
G_c_b= m_dot_c_b/(b*W_e) ;
x_c_b =0.75      ;  %vapor quality
G_c_b_eq = G_c_b*( (1-x_c_b)+( x_c_b *(rho_c_b_L/rho_c_b_V)^(0.5) ) );
Re_c_b_eq = (G_c_b_eq*D_h)/(mu_c_b);

%Evaporating Heat Transfer Coeff:
h_c_b = 5.323*(k_c_b/D_h)*Re_c_b_eq^(0.42)*pr_c_b^(1/3) ;
%heat tranfer area of zone b (Evaporator)
h_h_b = sum_R_ice/ (2*pi*L_ice) %haet transfer coefficient due to soldification of the pcm 
T_storing  = 0; %[C]  % initiated ,, will be optimzed , perfectly ranges from 0 to -10 C

T_h_in_b = T_HTF_in ; % assume that the chiller operates when ice temp is equal to T_HTF_in( when the ice temp equals to the temp of the glycol going into storage in teh discharing cycle 
T_h_out_b  = T_storing ;  % the goal is get te tank into stoarge tempeature which typicall vary from -10 to T_melting, this will be optimized 
delta1_b = T_h_in_b- T_c_b;
delta2_b = T_h_out_b - T_c_b;
LMTD_b = (delta1_b-delta2_b)/log(delta1_b/delta2_b);
U_b = 1/ ((1/h_h_b)+(1/h_c_b)+ (t_p/k_wall) );
A_b = Q_evap_dot/(LMTD_b*U_b);
%Number of palte requied 
 N_p_b = ( A_b/(L_p*W_e) +2 ) ;

%Design of condenser,
cp_h_cond = cp_h_c    %cp(R134a,T=T_h_cond,P=P_h_cond)
k_h_cond =  k_h_c     %conductivity(R134a,T=T_h_cond,P=P_h_cond)
pr_h_cond =  pr_h_c    % prandtl(R134a,T=T_h_cond,P=P_h_cond)
mu_h_cond =  mu_h_c    %viscosity(R134a,T=T_h_cond,P=P_h_cond)
rho_h_cond_L = rho_h_c_L   %density(R134a,P=P_h_cond, x=0)
rho_h_cond_V = rho_h_c_V   %density(R134a,P=P_h_cond, x=1)
m_dot_h_cond = m_dot_c_b   %
Q_cond_dot = m_dot_h_cond *(h_g_c-h_f_c);
G_h_cond= m_dot_h_cond/(b*W_e);
x_h_cond =0.75 %vapor quality
G_h_cond_eq = G_h_cond*( (1-x_h_cond)+( x_h_cond *(rho_h_cond_L/rho_h_cond_V)^(0.5) ) );
Re_h_cond_eq = (G_c_b_eq*D_h)/(mu_h_cond);
% Condensing Heat Transfer Coeff:
h_h_cond = 4.118*(k_h_cond/D_h)*Re_h_cond_eq^(0.4)*pr_h_cond^(1/3);
 
% proprties of cooling water at 48.28 C (average Tof water entering and
% leaving the condenser) % becuase I didn't take HVAC , I just knew as I'm conducting my literature review it is
% not necessary to use cooling tower, it becomes necessary for larger scale
% HVAC systems
cp_c_cond = 4180
k_c_cond = 0.63
pr_c_cond = 4.3
mu_c_cond = 0.55e-3
rho_c_cond = 988
m_dot_cooling_tower = 43.2e-3*Q_cond_dot
G_c_cond = m_dot_cooling_tower/(b*W_e)
Re_c_cond = (G_c_cond *d_eq)/ ( mu_c_cond)
f_c_cond= ( (1.82*log(Re_c_cond) ) - 1.64)^(-2)
Nusselt_c_cond = ( (f_c_cond/ 8)* (Re_c_cond-1) *pr_c_cond ) / ( ( 12.7*(f_c_cond/8)^(0.5) *(pr_c_cond^(2/3) -1) ) +1.07 )
h_c_cond= (Nusselt_c_cond*k_c_cond)/(d_eq)

% heat tranfer area of zone b (Condenser)

delta1_cond = T_h_cond - T_c_out_cond ;
delta2_cond = T_h_cond- T_c_in_cond;
LMTD_cond = (delta1_cond-delta2_cond)/log(delta1_cond/delta2_cond);
U_cond = 1 / ((1/h_h_cond)+(1/h_c_cond)+ (t_p/k_wall) );
A_cond = Q_cond_dot/(LMTD_cond*U_cond);
%  Number of palte required for zone a
N_p_cond = ( A_cond/(L_p*W_e) +2 )

% requied compressor power
W_dot_compressor = m_dot_h_cond *(h_g_c-h_g_evp)
COP= Q_evap_dot/W_dot_compressor

%cost calculations for the charing cycle(Capital cost)
% Evaporator:
C_evap = 16648.3 *A_b^(0.6123);
%Condenser:
 C_cond = (516.621*A_cond)+268.45;
 %Compressor :
 C_comp =( (39*m_dot_h_cond)/(0.9-0.6))*( P_cond/P_evap)*log(P_cond/P_evap);
% Expansion valve:
C_ExpV = 114.5*m_dot_h_cond;
%cooling twoerL:
C_cooling_tower = 746.749 *(m_dot_cooling_tower^0.79)*(T_coooling_tower_df^0.57)* ((T_c_out_cond- T_wb)^(-0.9924))*( (0.022*T_wb)  +0.39  )^(2.447);
% electricity cost, note that, for now I ignored the electric consumption
% cost of the pump in the charing cycle, fans in the AHS and Cooling Tower.
c_elc_off_peak=  0.09 ;  % [$/kWh] off-peak rating for Melbourne FL
c_elc_on_peak = 0.14 ;% [$/kWh] on-peak rating for Melbourne Fl
C_elect = (W_dot_compressor*(c_elc_off_peak/3600)) +(   W_pumping_inlet  *(c_elc_on_peak/3600)    )

N_on= 11*5*4*12; % number of operating(discharing) cycles (hours) for a 5 days a weak in 12 months 
N_off = 13*5*4*12; % number of charing cycles (hours) for a 5 days a weak in 12 months 
 
% The penalty cost of CO2 emission (CO2 ) 
E_cons_A = (W_dot_compressor*N_off)+ (  W_pumping_inlet*N_on)
emm_factor_co2 = 0.968 % [kg/kWh]this is  CO2 emission factor
mass_co2= emm_factor_co2*( E_cons_A)   % [kg] this teh annual mass of co2 produced by the system 
c_co2 = 90 % The penalty cost of CO2 emission (cCO2 ) was considered as 90 USdollars per ton of carbon dioxide emissions
 C_env =( (mass_co2/1000 )* c_co2 ) % the cost of co2 emission , this is a rough estimate as I ignored many components on the system

 C_HEX = (516.621*A_cond)+268.45*F_p* F_m  * interpolatedFL(i) %cost of tank HEX

C_investment= C_HEX +C_pumping +C_evap + C_cond + C_comp + C_ExpV + C_cooling_tower+C_st
c_total = C_investment +C_elect + C_env % the  main objective function to be minimized, includes enviromental aspects
% main results for discharing cycle:

disp(['Pumping Cost: ', num2str(C_pumping)]);
disp(['Storage Unit Cost: ', num2str(C_st)]);
disp(['Tank Heat Exchanger Cost: ', num2str(C_HEX)]);
disp(['mass flow rate of HTF: ', num2str(m_dot_HTF)]);
disp(['Volume of ice : ', num2str(V_ice)]);
disp(['Heat Transfer Area : ', num2str(A_ice)]);
disp(['Length required for tank tubes  based on cost: ', num2str(L_ice)]);
disp(['Number of tube in Tnak driven by cost criteria: ', num2str(N)]);
disp(['Outer Diamter: ', num2str(D_o)]);
disp(['HTF Temp into the Tank: ', num2str(T_HTF_in)]);
disp(['HTF Temp out from the Tank: ', num2str(T_HTF_out)]);
% main results for charing cycle:
disp(['Capital cost of condenser: ', num2str(C_cond)]);
disp(['Capital cost of Evaporator : ', num2str(C_evap)]);
disp(['Capital cost of compressor: ', num2str(C_comp)]);
disp(['Capital cooling tower: ', num2str(C_cooling_tower)]);
disp(['Capital cost of Expnasion Valve : ', num2str(C_ExpV)]);
disp(['Heat transfer area of the condenser : ', num2str(A_cond)]);
disp(['Heat transfer area of the evaporator : ', num2str(A_b)]);
disp(['Number of plates for the condenser : ', num2str(N_p_cond)]);
disp(['Number of plates for the Evaporator  : ', num2str(N_p_b)]);
disp(['cost of electricity: ', num2str(C_elect)])
disp(['cost of investment: ', num2str(C_investment)]);
disp(['cost of co2 emission: ', num2str(c_co2)]);
disp(['Total Cost: ', num2str(c_total)]);




end
