%Design of teh components of the charing cycle: 

W_e = 0.253 ; %[m] width of the plate
L_p = 0.456 ;%[m]
t_p = 0.002 ;%[m] // Plate thickness
beta_chovron = 0.785 ; % // Chevron angle
b = 0.002     ;   %[m]
pco = 0.004   ;   %[m] // corrugation pitch
X_x= (b*pi)/ pco ; % // Wavenumber
phi = (1/6) * ( 1+ (1+(X_x^2) )^(0.5)+ 4*(1+( (X_x^2)/2) )^(0.5) );  %// Arae Increase Factor
D_h = (2*b)/ phi ; %[m]
d_eq = 2*b  ;     %// eqivalint diameter
k_wall = 15;% [W/m-K]  %//conductivity of stainless steel



% Load the data table
opts = detectImportOptions(filename, 'VariableNamingRule', 'preserve');
dataTable = readtable(filename, opts);


% Given Temps 
T_c_b = -20 ;    % this will be optimized  T_c_b is the saturated evaporator temp and it varies from -30 to T_storing_Temp 
T_wb= 26.6         % this is teh wet bulp temp opteined from the design cheet of A/C system in Melboure Fl
T_c_in_cond = 35 %The temp of the cooling water coming from the cooling tower to the condenser 
T_c_out_cond = 40.56   % the temp the cooling water coming from out teh condenser 
T_coooling_tower_df =T_c_out_cond-T_c_in_cond % a temp differnce of 5.56 is typical for cooling tower 
T_h_cond = T_c_out_cond+5; % The saturated temp of condenser,T_h_cond must be kept above T_wetbulp and making sure does not exceed 60 C 
Temp1= T_h_cond;   % Temp1, calling the proprties of R134a at Temp_1, this value is fixed and not going to be optz for now
Temp2 = T_c_b;      % Temp2, calling the proprties of R134 at Temp_2,  this valu will be varied, optimized 

% proprties of R-134a at saturated Temp for evaporator  

propertiesAtTemp2 = getPropertiesForTemp(Temp2 , dataTable);
cp_h_evp = propertiesAtTemp2.cpLiquid;
k_h_evp = propertiesAtTemp2.kLiquid;
pr_h_evp = propertiesAtTemp2.PrLiquid;
mu_h_evp = propertiesAtTemp2.muLiquid;
rho_h_evp_L = propertiesAtTemp2.DensityLiquid;
rho_h_evp_V = propertiesAtTemp2.DensityVapor;
h_f_evp = propertiesAtTemp2.hf;
h_g_evp = propertiesAtTemp2.hg;
P_evap = propertiesAtTemp2.Pressure

% proprties of R-134a at saturated Temp for condenser 
propertiesAtTemp1 = getPropertiesForTemp(Temp1 , dataTable);
cp_h_c = propertiesAtTemp1.cpLiquid;
k_h_c = propertiesAtTemp1.kLiquid;
pr_h_c = propertiesAtTemp1.PrLiquid;
mu_h_c = propertiesAtTemp1.muLiquid;
rho_h_c_L = propertiesAtTemp1.DensityLiquid;
rho_h_c_V = propertiesAtTemp1.DensityVapor;
h_f_c = propertiesAtTemp1.hf;
h_g_c= propertiesAtTemp1.hg;
P_cond = propertiesAtTemp1.Pressure

% storing the proprties in the following variables for evaporator:
cp_c_b =cp_h_evp ; 
k_c_b = k_h_evp ;
pr_c_b = pr_h_evp;
mu_c_b = mu_h_evp;
rho_c_b_L =   rho_h_evp_L ;     %density(R-134a,P=P_c_b, x=0)
rho_c_b_V = rho_h_evp_V  ;      %density(R-134a,P=P_c_b, x=1) 
h_in_evap = h_f_evp     ;
h__out_evap = h_g_evp;

% Design the evaporator:

Q_st_dot = 22220; %[Wh]Power of evaporator
t_ch = 8 ; %h 
Q_evap_dot = Q_st_dot / t_ch ; %W

m_dot_c_b = Q_evap_dot  /(h__out_evap - h_in_evap )   ; % [kg/s], the mass flow rate in teh charing cycle 
G_c_b= m_dot_c_b/(b*W_e) ;
x_c_b =0.75      ;  %vapor quality
G_c_b_eq = G_c_b*( (1-x_c_b)+( x_c_b *(rho_c_b_L/rho_c_b_V)^(0.5) ) );
Re_c_b_eq = (G_c_b_eq*D_h)/(mu_c_b);

%Evaporating Heat Transfer Coeff:
h_c_b = 5.323*(k_c_b/D_h)*Re_c_b_eq^(0.42)*pr_c_b^(1/3) ;
%heat tranfer area of zone b (Evaporator)
R_wall = 0.02
L_ice = 2 
h_h_b = R_wall/ (2*pi*L_ice)
T_storing  = 0; %[C]
T_HTF_in = 12; % [C]
T_h_in_b = T_HTF_in ; % assume that the chiller operates when ice temp is equal to T_HTF_in( when the ice temp equals to the temp of the glycol going into storage in teh discharing cycle 
T_h_out_b  = T_storing ;  % the goal is get te tank into stoarge tempeature which typicall vary from -10 to T_melting, this will be optimized 
delta1_b = T_h_in_b- T_c_b;
delta2_b = T_h_out_b - T_c_b;
LMTD_b = (delta1_b-delta2_b)/log(delta1_b/delta2_b);
U_b = 1/ ((1/h_h_b)+(1/h_c_b)+ (t_p/k_wall) );
A_b = Q_evap_dot/(LMTD_b*U_b);
%Number of palte requied 
 N_p_b = ( A_b/(L_p*W_e) +2 ) ;

%Design of condenser,

cp_h_cond = cp_h_c    %cp(R134a,T=T_h_cond,P=P_h_cond)
k_h_cond =  k_h_c     %conductivity(R134a,T=T_h_cond,P=P_h_cond)
pr_h_cond =  pr_h_c    % prandtl(R134a,T=T_h_cond,P=P_h_cond)
mu_h_cond =  mu_h_c    %viscosity(R134a,T=T_h_cond,P=P_h_cond)
rho_h_cond_L = rho_h_c_L   %density(R134a,P=P_h_cond, x=0)
rho_h_cond_V = rho_h_c_V   %density(R134a,P=P_h_cond, x=1)
m_dot_h_cond = m_dot_c_b   %
Q_cond_dot = m_dot_h_cond *(h_g_c-h_f_c);
G_h_cond= m_dot_h_cond/(b*W_e);
x_h_cond =0.75 %vapor quality
G_h_cond_eq = G_h_cond*( (1-x_h_cond)+( x_h_cond *(rho_h_cond_L/rho_h_cond_V)^(0.5) ) );
Re_h_cond_eq = (G_c_b_eq*D_h)/(mu_h_cond);
% Condensing Heat Transfer Coeff:
h_h_cond = 4.118*(k_h_cond/D_h)*Re_h_cond_eq^(0.4)*pr_h_cond^(1/3);
 
% proprties of cooling water at 48.28 C (average Tof water entering and leaving the condenser)
cp_c_cond = 4180
k_c_cond = 0.63
pr_c_cond = 4.3
mu_c_cond = 0.55e-3
rho_c_cond = 988
m_dot_cooling_tower = 43.2e-3*Q_cond_dot
G_c_cond = m_dot_cooling_tower/(b*W_e)
Re_c_cond = (G_c_cond *d_eq)/ ( mu_c_cond)
f_c_cond= ( (1.82*log(Re_c_cond) ) - 1.64)^(-2)
Nusselt_c_cond = ( (f_c_cond/ 8)* (Re_c_cond-1) *pr_c_cond ) / ( ( 12.7*(f_c_cond/8)^(0.5) *(pr_c_cond^(2/3) -1) ) +1.07 )
h_c_cond= (Nusselt_c_cond*k_c_cond)/(d_eq)

% heat tranfer area of zone b (Condenser)

delta1_cond = T_h_cond - T_c_out_cond ;
delta2_cond = T_h_cond- T_c_in_cond;
LMTD_cond = (delta1_cond-delta2_cond)/log(delta1_cond/delta2_cond);
U_cond = 1 / ((1/h_h_cond)+(1/h_c_cond)+ (t_p/k_wall) );
A_cond = Q_cond_dot/(LMTD_cond*U_cond);
%  Number of palte required for zone a
N_p_cond = ( A_cond/(L_p*W_e) +2 )

% requied compressor power
W_dot_compressor = m_dot_h_cond *(h_g_c-h_g_evp)
COP= Q_evap_dot/W_dot_compressor

%cost calculations for the charing cycle(Capital cost)
% Evaporator:
C_evap = 16648.3 *A_b^(0.6123);
%Condenser:
 C_cond = (516.621*A_cond)+268.45;
 %Compressor :
 C_comp =( (39*m_dot_h_cond)/(0.9-0.6))*( P_cond/P_evap)*log(P_cond/P_evap);
% Expansion valve:
C_ExpV = 114.5*m_dot_h_cond;
%cooling twoerL:
C_cooling_tower = 746.749 *(m_dot_cooling_tower^0.79)*(T_coooling_tower_df^0.57)* ((T_c_out_cond- T_wb)^(-0.9924))*( (0.022*T_wb)  +0.39  )^(2.447);
% electricity cost, note that, for now I ignored the electric consumption
% cost of the pump in the charing cycle, fans in the AHS and Cooling Tower.
c_elc_off_peak=  0.09 ;  % [$/kWh] off-peak rating for Melbourne FL
c_elc_on_peak = 0.14 ;% [$/kWh] on-peak rating for Melbourne Fl
C_elect = (C_comp*(c_elc_off_peak/3600)) %+(   C_pumping  *(c_elc_on_peak/3600)    )

N_on= 11*5*4*12; % number of operating(discharing) cycles (hours) for a 5 days a weak in 12 months 
N_off = 13*5*4*12; % number of charing cycles (hours) for a 5 days a weak in 12 months 
 
% The penalty cost of CO2 emission (CO2 ) 
E_cons_A = (W_dot_compressor*N_off)%+ (  W_pumping_inlet*N_on)
emm_factor_co2 = 0.968 % [kg/kWh]this is  CO2 emission factor
mass_co2= emm_factor_co2*( E_cons_A)   % [kg] this teh annual mass of co2 produced by the system 
c_co2 = 90 % The penalty cost of CO2 emission (cCO2 ) was considered as 90 USdollars per ton of carbon dioxide emissions
 C_env =( (mass_co2/1000 )* c_co2 ) % the cost of co2 emission , this is a rough estimate as I ignored many components on the system
