% Local function to get all properties for a given temperature
function properties = getPropertiesForTemp(temp, dataTable)
    properties = struct();
    properties.Pressure = interpolateProperty(temp, dataTable, 'Pressure (Pa)');
    properties.DensityLiquid = interpolateProperty(temp, dataTable, 'Density Liquid (kg/m³)');
    properties.DensityVapor = interpolateProperty(temp, dataTable, 'Density Vapor (kg/m³)');
    properties.hf = interpolateProperty(temp, dataTable, 'hf (J/kg)');
    properties.hg = interpolateProperty(temp, dataTable, 'hg (J/kg)');
    properties.hfg = interpolateProperty(temp, dataTable, 'hfg (J/kg)');
    properties.cpLiquid = interpolateProperty(temp, dataTable, 'cp Liquid (J/kg·K)');
    properties.cpVapor = interpolateProperty(temp, dataTable, 'cp Vapor (J/kg·K)');
    properties.kLiquid = interpolateProperty(temp, dataTable, 'k Liquid (W/m·K)');
    properties.kVapor = interpolateProperty(temp, dataTable, 'k Vapor (W/m·K)');
    properties.muLiquid = interpolateProperty(temp, dataTable, 'μ Liquid (kg/m·s)');
    properties.muVapor = interpolateProperty(temp, dataTable, 'μ Vapor (kg/m·s)');
    properties.PrLiquid = interpolateProperty(temp, dataTable, 'Pr Liquid');
    properties.PrVapor = interpolateProperty(temp, dataTable, 'Pr Vapor');
end