% Local function to interpolate property
function value = interpolateProperty(temp, dataTable, propertyName)
    temperatures = dataTable.('Temperature (°C)');
    properties = dataTable.(propertyName);
    value = interp1(temperatures, properties, temp, 'linear', 'extrap');
end