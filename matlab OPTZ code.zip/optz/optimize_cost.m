close all
clear all
clc 
filename = 'R134a_properties.xlsx'; 
fitnessFunction = @(x) calculate_cost(x, filename); 


nvars = 9; % Number of variables 

% The bounds for the decsion variables 
LB =[0.1, 10, 0.05, 11, 3, 6.4e-3, 0.91e-3,-10,-30]; % Lower bounds
UB = [6.0960, 150, 0.2, 13, 5, 101.6e-3, 1.63e-3,0,0]; % Upper bounds

% Now Setting up the  options for the genetic algorithm
options = optimoptions('ga', 'Display', 'iter', 'UseParallel', true);



% Runing the genetic algorithm with custom constraints
[x, fval] = ga(fitnessFunction, nvars, [], [], [], [], LB, UB, @customConstraints, options);

% Display the results
disp('Optimal Solution:');
disp(['L_ice: ', num2str(x(1)), ' N: ', num2str(x(2)), ' m_dot_HTF: ', num2str(x(3)), ' T_HTF_in: ', num2str(x(4)), ' T_HTF_out: ', num2str(x(5)), ' D_o: ', num2str(x(6)), ' tube_t: ', num2str(x(7)), ' T_storing: ', num2str(x(8)), ' T_c_b: ', num2str(x(9))]);
disp(['Minimum Cost: ', num2str(fval)]);













% Custom constraints function that accepts T_fp_HTF as a parameter
function [c, ceq] = customConstraints(x)
    % Extracting  the decision variables that are relevant for the constraints
    D_o = x(6);
    tube_t = x(7);
    T_storing = x(8);
    T_c_b = x(9);
    N= x(2);
     L_ice = x(1);
  h_l_ice =336e3 ;
 Q_st_J = 87984e3; % J, storage capacity required in J
    rho_ice = 917; % kg/m^3
    V_ice = Q_st_J / (rho_ice * h_l_ice); % m^3, actual ice volume
    V_tank = V_ice/(1-0.20); % m^3, total tank volume (includes 20% extra for pipes and clearance)
    V_tube = N*pi*0.25*(D_o^2)*L_ice; % m^3, volume of tubes
    height = (V_tank/(pi*0.25))^(1/3); % m, height of the tank




    % Initialize the constraints array
    c = zeros(3, 1); % Now we have 5 constraints

    % constaraint (1):  D_o and its corresping  tube_t
    
    if any(D_o == [6.4e-3, 9.5e-3, 15.9e-3])
        valid_tube_t = 0.91e-3;
    elseif any(D_o == [12.7e-3, 19.1e-3])
        valid_tube_t = 1.02e-3;
    elseif any(D_o == [22.2e-3, 25.4e-3, 28.6e-3, 31.8e-3, 34.9e-3, 38.1e-3, 41.3e-3, 44.5e-3])
        valid_tube_t = 1.22e-3;
    elseif any(D_o == [50.8e-3, 54e-3, 66.7e-3, 76.2e-3, 101.6e-3])
        valid_tube_t = 1.63e-3;
    else
        valid_tube_t = NaN; % Invalid combination
    end
    % Constraint is satisfied if tube_t matches the valid value
    c(1) = (tube_t ~= valid_tube_t);

   % constarint (2), the evaporator presuure anx T_storing :
    % c(2) will be < 0 if T_c_b < T_storing
    c(2) = T_c_b - T_storing;
    % c(3) will be < 0 if T_storing > 0
    c(3) = -T_storing ;  % where 1e-6 is the smallest value you consider safely above zero
    
    % Geometric constraints for the tank , 4 and 5 % it's ignored for this
    % project , assume the dimentionsns of the tank is unknown 
c(4) = V_ice - V_tank + V_tube; % V_tube <= (V_tank - V_ice)
   c(5) = L_ice - height; % L_ice < height

    ceq = [];

end


