% Load the data table
opts = detectImportOptions(filename, 'VariableNamingRule', 'preserve');
dataTable = readtable(filename, opts);


%  the function for a specific temperature
Temp2 = 5; % testing 
propertiesAtTemp2 = getPropertiesForTemp(Temp2 , dataTable);
cp_h_cond = propertiesAtTemp2.cpLiquid;
k_h_evp = propertiesAtTemp2.kLiquid;
pr_h_evp = propertiesAtTemp2.PrLiquid;
mu_h_evp = propertiesAtTemp2.muLiquid;
rho_h_evp_L = propertiesAtTemp2.DensityLiquid;
rho_h_evp_V = propertiesAtTemp2.DensityVapor;
h_f_evp = propertiesAtTemp2.hf;
h_f_evp = propertiesAtTemp2.hf;
h_g_evp = propertiesAtTemp2.hg;

Temp3 = 10; % testing
propertiesAtTemp3 = getPropertiesForTemp(Temp3 , dataTable);
cp_h_evap = propertiesAtTemp3.cpLiquid;
%k_h_cond = propertiesAtTemp2.kLiquid;
%pr_h_cond = propertiesAtTemp2.PrLiquid;
%mu_h_cond = propertiesAtTemp2.muLiquid;
%rho_h_cond_L = propertiesAtTemp2.DensityLiquid;
%rho_h_cond_V = propertiesAtTemp2.DensityVapor;